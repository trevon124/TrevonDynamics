// api/ai.js — Server-side Claude proxy. Works when ANTHROPIC_API_KEY is set.
// If key not set, returns helpful fallback text instead of crashing.

const https = require("https");

module.exports = async (req, res) => {
  res.setHeader("Access-Control-Allow-Origin",  "*");
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");
  if (req.method === "OPTIONS") return res.status(200).end();
  if (req.method !== "POST")    return res.status(405).json({ error: "POST only" });

  const { type, lead, sender_name, sender_company } = req.body || {};
  if (!lead || !type) return res.status(400).json({ error: "type and lead are required" });

  const loc  = [lead.city, lead.state].filter(Boolean).join(", ") || "their market";
  const sigs = [
    lead.email          && "verified email",
    lead.phone          && "direct phone",
    lead.website        && "professional website",
    lead.license_number && `license #${lead.license_number}`,
    lead.broker_name    && `brokered by ${lead.broker_name}`,
  ].filter(Boolean);

  // ── Fallback if no API key ──────────────────────────────────────────────────
  if (!process.env.ANTHROPIC_API_KEY) {
    const fallbacks = {
      summary: `Active licensed real estate agent in ${loc}. ${sigs.length ? `Contact signals: ${sigs.join(", ")}.` : ""} License verified through state board — confirmed currently active.`,
      explain: `This lead scored ${lead.score || 0}/10 based on available contact information. ${lead.email ? "Email present (+3)." : "No email found (-3)."} ${lead.phone ? "Phone available (+3)." : "No phone listed (-3)."} ${lead.website ? "Website found (+2)." : "No website (-2)."}`,
      outreach: `Hi ${lead.name},\n\nI came across your license listing through the ${lead.state || "state"} real estate commission and wanted to reach out directly.\n\nI work with ${sender_company || "our company"} helping active agents like yourself access qualified buyer and seller leads in the ${loc} market. Many of the agents we work with have seen a significant increase in closings within their first 60 days.\n\nWould you be open to a quick 15-minute call this week to see if there's a fit? I think there's a real opportunity here given your presence in ${loc}.\n\nBest regards,\n${sender_name || "Your Name"}`,
      subject: `Quick question about your ${loc} listings\nRE: Qualified buyer leads for ${lead.name}\nYour ${lead.state || "state"} license + our leads = more closings`,
    };
    return res.status(200).json({ success: true, text: fallbacks[type] || "Content generated.", fallback: true });
  }

  // ── Real Claude API call ────────────────────────────────────────────────────
  const missing = ["email","phone","website"].filter(k => !lead[k]);
  const configs = {
    summary: {
      system:     "Write a 2-sentence CRM lead summary for an active licensed real estate agent. Be specific. No markdown.",
      user:       `Agent: ${lead.name}\nMarket: ${loc}\nScore: ${lead.score}/10\nLicense: ${lead.license_number || "verified"} — ACTIVE\nBroker: ${lead.broker_name || "independent"}\nContact: ${sigs.join(", ") || "license only"}`,
      max_tokens: 150,
    },
    explain: {
      system:     "Explain this lead score in 2 direct sentences. No markdown.",
      user:       `Score: ${lead.score}/10\nHas: ${sigs.join(", ") || "license only"}\nMissing: ${missing.join(", ") || "nothing"}`,
      max_tokens: 120,
    },
    outreach: {
      system:     "Write a short, warm cold outreach email. 3 paragraphs. No markdown. No subject line. End with CTA for 15-min call.",
      user:       `Agent: ${lead.name} — ACTIVE licensed in ${loc}\nLicense: ${lead.license_number || "state verified"}\nBroker: ${lead.broker_name || "N/A"}\nSender: ${sender_name || "Your Name"} at ${sender_company || "Your Company"}`,
      max_tokens: 450,
    },
    subject: {
      system:     "Write 3 cold email subject lines. One per line. No numbers. No dashes.",
      user:       `Reaching out to ${lead.name}, active licensed agent in ${loc}.`,
      max_tokens: 80,
    },
  };

  const cfg = configs[type];
  if (!cfg) return res.status(400).json({ error: "Unknown type: " + type });

  try {
    const payload = JSON.stringify({
      model: "claude-sonnet-4-6", max_tokens: cfg.max_tokens,
      system: cfg.system, messages: [{ role: "user", content: cfg.user }],
    });

    const result = await new Promise((resolve, reject) => {
      const req2 = https.request({
        hostname: "api.anthropic.com", port: 443, path: "/v1/messages", method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Content-Length": Buffer.byteLength(payload),
          "x-api-key": process.env.ANTHROPIC_API_KEY,
          "anthropic-version": "2023-06-01",
        },
        timeout: 30000,
      }, r => {
        let d = ""; r.on("data", c => d += c);
        r.on("end", () => { try { resolve(JSON.parse(d)); } catch { reject(new Error("Parse error")); } });
      });
      req2.on("error", reject).on("timeout", () => { req2.destroy(); reject(new Error("Timeout")); });
      req2.write(payload); req2.end();
    });

    if (result.error) return res.status(200).json({ success: false, error: result.error.message });
    return res.status(200).json({ success: true, text: result.content?.[0]?.text?.trim() || "" });

  } catch (err) {
    return res.status(200).json({ success: false, error: err.message });
  }
};
