# Lead Engine — Real Estate CRM

Deploy to Vercel in 3 minutes. Get a live public URL with real AI features.

---

## Deploy to Vercel (3 Steps)

### Step 1 — Push to GitHub
1. Create a new repo at github.com (name it anything, e.g. `lead-engine`)
2. Upload all these files to the repo (drag & drop in GitHub UI)

### Step 2 — Connect to Vercel
1. Go to [vercel.com](https://vercel.com) → Sign up free → New Project
2. Import your GitHub repo
3. Click **Deploy** (no build settings needed)

### Step 3 — Add Your API Key
1. In Vercel → Your Project → Settings → Environment Variables
2. Add: `ANTHROPIC_API_KEY` = `sk-ant-your-key-here`
3. Click **Redeploy**

**You now have a live URL like `https://lead-engine-abc123.vercel.app`**

---

## File Structure

```
/
├── vercel.json          ← Vercel routing config
├── api/
│   ├── ai.js           ← Serverless function: proxies Claude API calls
│   └── scrape.js       ← Serverless function: scrapes real estate directories
└── public/
    └── index.html      ← Complete frontend app
```

---

## How It Works

```
Browser  ──POST /api/ai──►  Vercel Serverless  ──►  Anthropic Claude API
Browser  ──POST /api/scrape►  Vercel Serverless  ──►  Public Directories
```

- **API key is secure** — stored as Vercel env var, never sent to browser
- **AI features**: summary, score explanation, outreach email, subject lines
- **Scraping**: hits YellowPages + Yelp for real agent data
- **Data persists** in browser localStorage per user

---

## API Endpoints (live on your Vercel URL)

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/ai` | Generate AI content for a lead |
| POST | `/api/scrape` | Scrape agents from public directories |

### /api/ai body
```json
{
  "type": "summary | explain | outreach | subject",
  "lead": { "name": "...", "email": "...", "score": 9, ... },
  "sender_name": "Your Name",
  "sender_company": "Your Company"
}
```

### /api/scrape body
```json
{ "city": "Houston", "state": "TX" }
```

---

## Get Your Anthropic API Key
Go to [console.anthropic.com](https://console.anthropic.com) → API Keys → Create Key
